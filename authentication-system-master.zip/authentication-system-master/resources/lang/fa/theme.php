<?php
return [
    /*** NavBar ***/ 
    'home' => 'صفحه اصلی',
    'login' => 'ورود',
    'register' => 'ثبت نام',
    'profile' => 'پروفایل',
    'search' => 'جستجو',
    'logout' => 'خروج',
];
?>