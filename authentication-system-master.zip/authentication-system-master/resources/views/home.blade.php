@extends('layouts.app')
@section('title','صفحه اصلی')
@section('content')
    <div class="row">
        <div class="col-md-12" style="padding: 40px;">
            <h1>به وب ویت خوش آمدید</h1>
        </div>
    </div>
@endsection